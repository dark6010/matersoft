<template>
<table class="table">
    <thead>
      <tr>
        <th scope="col">Title</th>
        <th scope="col">Year</th>
        <th scope="col">imdbID</th>
        <th scope="col">type</th>
        <th scope="col">poster</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Mark</td>
        <td>Otto</td>
        <td>@mdo</td>
        <td>@mdo</td>
        <td>@mdo</td>
      </tr>
      <tr>
        <td>Jacob</td>
        <td>Thornton</td>
        <td>@mdo</td>
        <td>@mdo</td>
        <td>@fat</td>
      </tr>
      <tr>
        <td>Larry</td>
        <td>the Bird</td>
        <td>@twitter</td>
        <td>@twitter</td>
        <td>@twitter</td>
      </tr>
    </tbody>
  </table>
</template>
<script setup lang="ts">
</script>